package com.vpocket.myapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.vpocket.R


class ChildMain : AppCompatActivity() {

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.child_main)  //pagrindinis vaiko psl
        }
    }
