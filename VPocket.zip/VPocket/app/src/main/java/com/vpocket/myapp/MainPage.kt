package com.vpocket.myapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.vpocket.R


class MainPage : AppCompatActivity() {

    private lateinit var vaikoButton: Button
    private lateinit var tevoButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_page)

        // mygtukai
        vaikoButton = findViewById(R.id.vaiko_button) // Find the button by ID
        tevoButton = findViewById(R.id.tevo_button)  // Initialize the tevoButton (Tėvai button)


        // Set up the button click listener for Vaiko (Child) button
        vaikoButton.setOnClickListener {
            val intent = Intent(this, ChildLogin::class.java)
            startActivity(intent)
        }

        // Set up the button click listener for Tevo (Parents) button
        tevoButton.setOnClickListener {
            val intent = Intent(this, Login::class.java)  // Make sure Login activity is correct
            startActivity(intent)
        }

    }

}



